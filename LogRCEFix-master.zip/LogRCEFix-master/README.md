# LogRCEFix
Protect your players from the log4j RCE exploit.

PLEASE NOTE THAT THIS DOES NOT PROTECT YOUR SERVER, IT ONLY PREVENTS THE MESSAGE FROM BEING SENT TO PLAYERS. TO PROTECT YOUR SERVER, REFER TO https://www.minecraft.net/en-us/article/important-message--security-vulnerability-java-edition